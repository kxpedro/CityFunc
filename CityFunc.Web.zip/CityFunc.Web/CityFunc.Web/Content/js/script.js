﻿$(document).ready(function($){

    $('#CPF').mask("999.999.999-99");
    $('#CEP').mask("99999-999");
    $('#Telefone').mask("(99) 9999-9999");

});